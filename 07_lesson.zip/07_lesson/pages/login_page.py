from selenium.webdriver.common.by import By


class LoginPage:

    def __init__(self, driver):
        self.driver = driver

        self.delay_input = (By.CSS_SELECTOR, "#delay")
        self.result = (By.CSS_SELECTOR, ".screen")

    def open(self):
        self.driver.get("https://www.saucedemo.com/")

    def login(self):
        login = self.driver.find_element(By.ID, "user-name")
        login.send_keys("standard_user")

        password = self.driver.find_element(By.ID, "password")
        password.send_keys("secret_sauce")

    def quit(self):
        self.driver.quit()

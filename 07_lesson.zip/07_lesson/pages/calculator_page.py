from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class CalculatorPage:

    def __init__(self, driver):
        self.driver = driver

        # поле ввода задержки
        self.delay_input = (By.CSS_SELECTOR, "#delay")

        # поле вывода результата
        self.result = (By.CSS_SELECTOR, ".screen")

    def open(self):
        self.driver.get(
            "https://bonigarcia.dev/selenium-webdriver-java/"
            "slow-calculator.html"
        )

    def set_delay(self, value):

        delay = self.driver.find_element(
            *self.delay_input
        )

        delay.clear()
        delay.send_keys(value)

    def click_button(self, button):

        button_element = WebDriverWait(
            self.driver,
            60
        ).until(

            EC.element_to_be_clickable(

                (
                    By.XPATH,
                    f"//*[@id='calculator']/div[2]/button[text()='{button}']"
                )

            )

        )

        button_element.click()

        return self

    def get_result(self):

        WebDriverWait(
            self.driver,
            60
        ).until(

            lambda d:
            d.find_element(
                *self.result
            ).text != ""

        )

        return self.driver.find_element(
            *self.result
        ).text
